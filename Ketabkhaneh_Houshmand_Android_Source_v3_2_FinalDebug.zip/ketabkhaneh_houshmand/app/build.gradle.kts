plugins { id("com.android.application") }

android {
    namespace = "ir.behzad.smartlibrary"
    compileSdk = 35

    defaultConfig {
        applicationId = "ir.behzad.smartlibrary"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "1.0.1-alpha"
    }
}
