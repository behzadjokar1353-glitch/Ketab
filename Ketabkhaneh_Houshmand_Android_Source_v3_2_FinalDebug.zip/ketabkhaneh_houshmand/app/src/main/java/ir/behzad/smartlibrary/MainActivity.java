package ir.behzad.smartlibrary;

import android.app.*;
import android.os.*;
import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LibraryDb db; LinearLayout root, list; EditText search; long currentFolder=-1;
    final Set<Long> expanded=new HashSet<>();
    final int PURPLE=Color.rgb(101,86,184), NAVY=Color.rgb(16,20,38);
    @Override public void onCreate(Bundle b){super.onCreate(b);db=new LibraryDb(this);if(b!=null){currentFolder=b.getLong("currentFolder",-1);long[] ids=b.getLongArray("expanded");if(ids!=null)for(long id:ids)expanded.add(id);}showHome();}
    @Override protected void onSaveInstanceState(Bundle out){super.onSaveInstanceState(out);out.putLong("currentFolder",currentFolder);long[] ids=new long[expanded.size()];int i=0;for(Long id:expanded)ids[i++]=id;out.putLongArray("expanded",ids);}
    @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density);}
    TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);t.setPadding(dp(12),dp(9),dp(12),dp(9));return t;}
    GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    void base(String title){
        root=new LinearLayout(this);root.setOrientation(1);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setBackgroundColor(Color.rgb(245,246,251));
        // Respect system bars on Android versions that enforce edge-to-edge for target SDK 35.
        root.setFitsSystemWindows(true);
        LinearLayout bar=new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(12),dp(4),dp(12),dp(4));
        bar.setBackgroundColor(NAVY);
        ImageView brand=new ImageView(this);
        brand.setImageResource(R.drawable.ic_smart_library_logo);
        LinearLayout.LayoutParams logoParams=new LinearLayout.LayoutParams(dp(44),dp(44));
        logoParams.setMargins(dp(8),0,dp(10),0);
        bar.addView(brand,logoParams);
        TextView heading=text("☰   "+title,19,Color.WHITE);
        heading.setTypeface(null,android.graphics.Typeface.BOLD);
        heading.setOnClickListener(v->homeMenu());
        bar.addView(heading,new LinearLayout.LayoutParams(0,-1,1));
        root.addView(bar,new LinearLayout.LayoutParams(-1,dp(58)));
        setContentView(root);
    }
    void homeMenu(){
        String[] items={"باز کردن همه پوشه‌ها","بستن همه پوشه‌ها","درباره برنامه"};
        new AlertDialog.Builder(this).setTitle("منوی کتابخانه").setItems(items,(d,w)->{
            if(w==0){expandAll();renderTree();}
            else if(w==1){expanded.clear();renderTree();}
            else new AlertDialog.Builder(this).setTitle("کتابخانه هوشمند من").setMessage("نسخه ۱.۰.۱ آزمایشی — اطلاعات کتابخانه به‌صورت محلی روی دستگاه ذخیره می‌شود.").setPositiveButton("باشه",null).show();
        }).show();
    }
    void expandAll(){for(LibraryDb.Folder f:db.folders(null))expandBranch(f);}
    void expandBranch(LibraryDb.Folder f){expanded.add(f.id);for(LibraryDb.Folder child:db.folders(f.id))expandBranch(child);}
    void showHome(){
        base("کتابخانه هوشمند من");
        LinearLayout actions=new LinearLayout(this);actions.setPadding(dp(10),dp(8),dp(10),dp(4));
        Button add=button("＋ پوشه جدید"); add.setOnClickListener(v->newFolder(null));actions.addView(add,new LinearLayout.LayoutParams(0,dp(48),1));
        Button importB=button("＋ افزودن فایل");importB.setOnClickListener(v->pickFiles(-1));actions.addView(importB,new LinearLayout.LayoutParams(0,dp(48),1));
        root.addView(actions);
        search=new EditText(this);search.setSingleLine(true);search.setHint("جستجو در نام، نام مستعار، کلیدواژه و توضیحات…");search.setTextSize(14);search.setGravity(Gravity.RIGHT);search.setPadding(dp(14),0,dp(14),0);search.setBackground(bg(Color.WHITE,14));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(48));sp.setMargins(dp(12),dp(6),dp(12),dp(8));root.addView(search,sp);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);list=new LinearLayout(this);list.setOrientation(1);list.setPadding(dp(10),0,dp(10),dp(20));scroll.addView(list);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        Button expand=button("باز کردن همه پوشه‌ها");expand.setOnClickListener(v->{expandAll();renderTree();});root.addView(expand);
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){renderTree();}public void afterTextChanged(android.text.Editable e){}});
        renderTree();
    }
    Button button(String s){Button b=new Button(this);b.setText(s);b.setTextSize(13);b.setTextColor(Color.WHITE);b.setBackground(bg(PURPLE,12));return b;}
    void renderTree(){if(list==null)return;list.removeAllViews();String q=search==null?"":search.getText().toString();if(!q.trim().isEmpty()){for(LibraryDb.FileItem f:db.files(-1,q))addSearchResult(f);return;}for(LibraryDb.FileItem f:db.rootFiles())addFileRow(list,f);for(LibraryDb.Folder f:db.folders(null))addFolderRow(f,0);}
    void addFolderRow(LibraryDb.Folder f,int level){
        LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setBackground(bg(Color.WHITE,14));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(dp(level*12),dp(4),0,dp(4));card.setLayoutParams(cp);
        LinearLayout line=new LinearLayout(this);line.setGravity(Gravity.CENTER_VERTICAL);line.setPadding(dp(6),dp(2),dp(4),dp(2));
        TextView label=text((expanded.contains(f.id)?"⌄ ":"› ")+f.icon+"  "+f.name,16,Color.rgb(38,42,60));
        try{label.setTextColor(Color.parseColor(f.color));}catch(Exception ignored){}
        line.addView(label,new LinearLayout.LayoutParams(0,dp(52),1));
        TextView count=text(String.valueOf(db.files(f.id,"").size())+" فایل",12,Color.GRAY);line.addView(count);
        line.setOnClickListener(v->{if(expanded.contains(f.id))expanded.remove(f.id);else expanded.add(f.id);renderTree();});
        line.setOnLongClickListener(v->{folderMenu(f);return true;});card.addView(line);
        if(expanded.contains(f.id)){for(LibraryDb.FileItem fi:db.files(f.id,""))addFileRow(card,fi);
            for(LibraryDb.Folder child:db.folders(f.id))addFolderRowInto(card,child,level+1);
            Button sub=button("＋ زیرپوشه");sub.setOnClickListener(v->newFolder(f.id));card.addView(sub);
            Button imp=button("＋ افزودن فایل به این پوشه");imp.setOnClickListener(v->pickFiles(f.id));card.addView(imp);
        }
        list.addView(card);
    }
    void addFolderRowInto(LinearLayout parent,LibraryDb.Folder f,int level){
        LinearLayout wrap=new LinearLayout(this);wrap.setOrientation(1);wrap.setPadding(dp(8),0,0,0);
        TextView t=text((expanded.contains(f.id)?"⌄ ":"› ")+f.icon+"  "+f.name,15,Color.DKGRAY);
        try{t.setTextColor(Color.parseColor(f.color));}catch(Exception ignored){}
        t.setBackground(bg(0xFFF2F1FA,10));wrap.addView(t);
        t.setOnClickListener(v->{if(expanded.contains(f.id))expanded.remove(f.id);else expanded.add(f.id);renderTree();});
        t.setOnLongClickListener(v->{folderMenu(f);return true;});
        if(expanded.contains(f.id)){for(LibraryDb.FileItem fi:db.files(f.id,""))addFileRow(wrap,fi);for(LibraryDb.Folder ch:db.folders(f.id))addFolderRowInto(wrap,ch,level+1);Button sub=button("＋ زیرپوشه");sub.setOnClickListener(v->newFolder(f.id));wrap.addView(sub);Button imp=button("＋ افزودن فایل");imp.setOnClickListener(v->pickFiles(f.id));wrap.addView(imp);}
        parent.addView(wrap);
    }
    void addFileRow(LinearLayout parent,LibraryDb.FileItem f){
        TextView t=text("📄  "+f.name+"    ·    "+human(f.size),14,Color.rgb(55,60,75));t.setBackground(bg(0xFFF7F8FC,8));parent.addView(t);
        t.setOnClickListener(v->fileMenu(f));t.setOnLongClickListener(v->{fileMenu(f);return true;});
    }
    void addSearchResult(LibraryDb.FileItem f){TextView t=text("📄 "+f.name+"  ·  "+human(f.size),14,Color.DKGRAY);t.setBackground(bg(Color.WHITE,10));list.addView(t);t.setOnClickListener(v->fileMenu(f));}
    String human(long n){if(n<1024)return n+" B";if(n<1048576)return (n/1024)+" KB";return String.format(Locale.US,"%.1f MB",n/1048576.0);}
    void newFolder(Long parent){EditText e=new EditText(this);e.setHint("نام پوشه");new AlertDialog.Builder(this).setTitle(parent==null?"پوشه جدید":"زیرپوشه جدید").setView(e).setPositiveButton("ایجاد",(d,w)->{if(e.getText().toString().trim().length()>0){long id=db.addFolder(parent,e.getText().toString().trim());expanded.add(id);if(parent!=null)expanded.add(parent);renderTree();}}).setNegativeButton("انصراف",null).show();}
    void folderMenu(LibraryDb.Folder f){String[] opts={"افزودن فایل","افزودن زیرپوشه","تغییر رنگ پوشه","حذف پوشه"};new AlertDialog.Builder(this).setTitle(f.name).setItems(opts,(d,w)->{if(w==0)pickFiles(f.id);if(w==1)newFolder(f.id);if(w==2)styleFolder(f);if(w==3)new AlertDialog.Builder(this).setMessage("این پوشه، تمام زیرپوشه‌ها و رکورد فایل‌های داخل آن از کتابخانه حذف می‌شوند. فایل اصلی در حافظه دستگاه حذف نخواهد شد. ادامه می‌دهید؟").setPositiveButton("حذف", (x,y)->{db.deleteFolderTree(f.id);expanded.remove(f.id);renderTree();}).setNegativeButton("لغو",null).show();}).show();}
    void styleFolder(LibraryDb.Folder f){new AlertDialog.Builder(this).setTitle("رنگ پوشه").setItems(new String[]{"بنفش","آبی","سبز","قرمز","طلایی"},(d,w)->{String[] c={"#6556B8","#3185CE","#258A68","#C94B55","#D4A72C"};db.setFolderStyle(f.id,c[w],f.icon);renderTree();}).show();}
    void fileMenu(LibraryDb.FileItem f){String[] o={"باز کردن فایل","ویرایش مشخصات و برچسب","حذف از کتابخانه"};new AlertDialog.Builder(this).setTitle(f.name).setItems(o,(d,w)->{if(w==0)openFile(f);if(w==1)editMeta(f);if(w==2)new AlertDialog.Builder(this).setMessage("فقط رکورد کتابخانه حذف شود؟").setPositiveButton("حذف",(x,y)->{db.deleteFile(f.id);renderTree();}).setNegativeButton("لغو",null).show();}).show();}
    void editMeta(LibraryDb.FileItem f){LinearLayout box=new LinearLayout(this);box.setPadding(dp(12),0,dp(12),0);box.setOrientation(1);EditText a=new EditText(this);a.setHint("نام‌های مستعار با ویرگول");a.setText(f.aliases);EditText k=new EditText(this);k.setHint("کلیدواژه‌ها با ویرگول");k.setText(f.keywords);EditText desc=new EditText(this);desc.setHint("توضیحات");desc.setText(f.description);EditText tag=new EditText(this);tag.setHint("برچسب رنگی (مثلاً قرمز/زرد/سبز)");tag.setText(f.label);box.addView(a);box.addView(k);box.addView(desc);box.addView(tag);new AlertDialog.Builder(this).setTitle("مشخصات فایل").setView(box).setPositiveButton("ذخیره",(d,w)->{db.updateMeta(f.id,a.getText().toString(),k.getText().toString(),desc.getText().toString(),tag.getText().toString());renderTree();}).setNegativeButton("لغو",null).show();}
    void pickFiles(long folder){currentFolder=folder;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,41);}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==41&&res==RESULT_OK&&data!=null){if(data.getClipData()!=null){for(int x=0;x<data.getClipData().getItemCount();x++)saveUri(data.getClipData().getItemAt(x).getUri(),data.getFlags());}else if(data.getData()!=null)saveUri(data.getData(),data.getFlags());renderTree();}}
    void saveUri(Uri uri,int resultFlags){
        try {
            int grantFlags=resultFlags&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            boolean persisted=false;
            if((grantFlags&Intent.FLAG_GRANT_READ_URI_PERMISSION)!=0){
                // Persist only read access: the library never modifies the user's original file.
                try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);persisted=true;}
                catch(Exception ignored){ /* Some document providers issue temporary-only grants. */ }
            }
            String name="فایل";long size=0;String mime=getContentResolver().getType(uri);
            Cursor c=getContentResolver().query(uri,null,null,null,null);
            if(c!=null){try{if(c.moveToFirst()){int n=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(n>=0&&c.getString(n)!=null)name=c.getString(n);int z=c.getColumnIndex(OpenableColumns.SIZE);if(z>=0&&!c.isNull(z))size=c.getLong(z);}}finally{c.close();}}
            db.addFile(currentFolder,name,uri.toString(),mime,size);
            if(!persisted)Toast.makeText(this,"فایل ثبت شد؛ ارائه‌دهنده حافظه اجازه دسترسی پایدار نداد و ممکن است پس از راه‌اندازی مجدد در دسترس نباشد.",Toast.LENGTH_LONG).show();
        }catch(Exception e){Toast.makeText(this,"افزودن فایل ناموفق بود: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    void openFile(LibraryDb.FileItem f){
        try {
            Intent i=new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(Uri.parse(f.uri),f.mime==null||f.mime.trim().isEmpty()?"*/*":f.mime);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(i);
        } catch(android.content.ActivityNotFoundException e) {
            Toast.makeText(this,"برنامه‌ای برای باز کردن این نوع فایل نصب نیست",Toast.LENGTH_SHORT).show();
        } catch(SecurityException e) {
            Toast.makeText(this,"دسترسی به فایل منقضی شده است؛ فایل را دوباره به کتابخانه اضافه کنید",Toast.LENGTH_LONG).show();
        } catch(Exception e) {
            Toast.makeText(this,"باز کردن فایل ناموفق بود",Toast.LENGTH_SHORT).show();
        }
    }
}
