package ir.behzad.smartlibrary;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.*;

public class LibraryDb extends SQLiteOpenHelper {
    public LibraryDb(Context c) { super(c, "smart_library.db", null, 2); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE folders(id INTEGER PRIMARY KEY AUTOINCREMENT, parent_id INTEGER, name TEXT NOT NULL, color TEXT DEFAULT '#6556B8', icon TEXT DEFAULT '📁', sort_order INTEGER DEFAULT 0)");
        db.execSQL("CREATE TABLE files(id INTEGER PRIMARY KEY AUTOINCREMENT, folder_id INTEGER, name TEXT, uri TEXT, mime TEXT, size INTEGER, added_at INTEGER, aliases TEXT DEFAULT '', keywords TEXT DEFAULT '', description TEXT DEFAULT '', label TEXT DEFAULT '')");
        db.execSQL("CREATE TABLE tags(id INTEGER PRIMARY KEY AUTOINCREMENT, file_id INTEGER, tag TEXT)");
        db.execSQL("CREATE TABLE related(id INTEGER PRIMARY KEY AUTOINCREMENT, file_id INTEGER, related_file_id INTEGER)");
        db.execSQL("INSERT INTO folders(parent_id,name,color,icon) VALUES(NULL,'اسناد مهم','#D4A72C','⭐')");
        db.execSQL("INSERT INTO folders(parent_id,name,color,icon) VALUES(NULL,'تصاویر','#3185CE','🖼️')");
        db.execSQL("INSERT INTO folders(parent_id,name,color,icon) VALUES(NULL,'کتاب‌ها و PDF','#7B61A8','📚')");
        db.execSQL("INSERT INTO folders(parent_id,name,color,icon) VALUES(NULL,'فایل‌های کاری','#258A68','💼')");
        createIndexes(db);
    }
    private void createIndexes(SQLiteDatabase db) {
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_folders_parent ON folders(parent_id,sort_order)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_files_folder_added ON files(folder_id,added_at DESC)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_files_uri ON files(uri)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_tags_file ON tags(file_id)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_related_file ON related(file_id)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_related_target ON related(related_file_id)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldV,int newV) {
        if (oldV < 2) createIndexes(db);
    }
    public static class Folder {
        public long id, parent; public String name,color,icon;
        Folder(Cursor c){id=c.getLong(0); parent=c.isNull(1)?-1:c.getLong(1); name=c.getString(2); color=c.getString(3); icon=c.getString(4);}
    }
    public static class FileItem {
        public long id, folderId, size; public String name,uri,mime,aliases,keywords,description,label;
        FileItem(Cursor c){id=c.getLong(0);folderId=c.getLong(1);name=c.getString(2);uri=c.getString(3);mime=c.getString(4);size=c.getLong(5);aliases=c.getString(6);keywords=c.getString(7);description=c.getString(8);label=c.getString(9);}
    }
    public List<Folder> folders(Long parent) {
        List<Folder> a=new ArrayList<>(); Cursor c=getReadableDatabase().rawQuery(
            "SELECT id,parent_id,name,color,icon FROM folders WHERE "+(parent==null?"parent_id IS NULL":"parent_id=?")+" ORDER BY sort_order,id",
            parent==null?null:new String[]{String.valueOf(parent)});
        try{while(c.moveToNext())a.add(new Folder(c));}finally{c.close();} return a;
    }
    public long addFolder(Long parent,String name){
        ContentValues v=new ContentValues(); if(parent!=null)v.put("parent_id",parent);
        v.put("name",name); return getWritableDatabase().insert("folders",null,v);
    }
    public void addFile(long folder,String name,String uri,String mime,long size){
        ContentValues v=new ContentValues();v.put("folder_id",folder);v.put("name",name);v.put("uri",uri);
        v.put("mime",mime);v.put("size",size);v.put("added_at",System.currentTimeMillis());
        getWritableDatabase().insert("files",null,v);
    }
    public List<FileItem> files(long folder,String query){
        List<FileItem> a=new ArrayList<>(); String q="%"+query+"%";
        Cursor c=getReadableDatabase().rawQuery("SELECT id,folder_id,name,uri,mime,size,aliases,keywords,description,label FROM files WHERE (?=-1 OR folder_id=?) AND (name LIKE ? OR aliases LIKE ? OR keywords LIKE ? OR description LIKE ?) ORDER BY added_at DESC",
            new String[]{String.valueOf(folder),String.valueOf(folder),q,q,q,q});
        try{while(c.moveToNext())a.add(new FileItem(c));}finally{c.close();}return a;
    }
    public void updateMeta(long id,String aliases,String keywords,String desc,String label){
        ContentValues v=new ContentValues();v.put("aliases",aliases);v.put("keywords",keywords);v.put("description",desc);v.put("label",label);
        getWritableDatabase().update("files",v,"id=?",new String[]{String.valueOf(id)});
    }
    public void deleteFile(long id){
        SQLiteDatabase database=getWritableDatabase();
        database.beginTransaction();
        try {
            String[] args={String.valueOf(id)};
            database.delete("tags","file_id=?",args);
            database.delete("related","file_id=? OR related_file_id=?",new String[]{String.valueOf(id),String.valueOf(id)});
            database.delete("files","id=?",args);
            database.setTransactionSuccessful();
        } finally { database.endTransaction(); }
    }
    public List<FileItem> rootFiles() { return filesInFolder(-1); }
    public List<FileItem> filesInFolder(long folder) {
        List<FileItem> a=new ArrayList<>();
        Cursor c=getReadableDatabase().rawQuery("SELECT id,folder_id,name,uri,mime,size,aliases,keywords,description,label FROM files WHERE folder_id=? ORDER BY added_at DESC",new String[]{String.valueOf(folder)});
        try{while(c.moveToNext())a.add(new FileItem(c));}finally{c.close();} return a;
    }
    public void deleteFolderTree(long folderId) {
        SQLiteDatabase database=getWritableDatabase();
        database.beginTransaction();
        try {
            // Iterative traversal avoids stack overflow for deeply nested folder trees.
            Set<Long> folderIds=new LinkedHashSet<>();
            ArrayDeque<Long> pending=new ArrayDeque<>();
            pending.add(folderId);
            while(!pending.isEmpty()) {
                long id=pending.removeFirst();
                if(!folderIds.add(id)) continue;
                Cursor c=database.rawQuery("SELECT id FROM folders WHERE parent_id=?",new String[]{String.valueOf(id)});
                try { while(c.moveToNext()) pending.addLast(c.getLong(0)); }
                finally { c.close(); }
            }
            List<Long> fileIds=new ArrayList<>();
            for(Long id:folderIds) {
                Cursor c=database.rawQuery("SELECT id FROM files WHERE folder_id=?",new String[]{String.valueOf(id)});
                try { while(c.moveToNext()) fileIds.add(c.getLong(0)); }
                finally { c.close(); }
            }
            for(Long id:fileIds) {
                String[] args={String.valueOf(id)};
                database.delete("tags","file_id=?",args);
                database.delete("related","file_id=? OR related_file_id=?",new String[]{String.valueOf(id),String.valueOf(id)});
            }
            for(Long id:folderIds) {
                database.delete("files","folder_id=?",new String[]{String.valueOf(id)});
                database.delete("folders","id=?",new String[]{String.valueOf(id)});
            }
            database.setTransactionSuccessful();
        } finally { database.endTransaction(); }
    }
    public void setFolderStyle(long id,String color,String icon){
        ContentValues v=new ContentValues();v.put("color",color);v.put("icon",icon);
        getWritableDatabase().update("folders",v,"id=?",new String[]{String.valueOf(id)});
    }
}
